from django.apps import AppConfig


class ZerosugarappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "zerosugarApp"
