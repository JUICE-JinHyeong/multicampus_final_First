from django.contrib import admin
from django.urls import path, include
from zerosugarApp import views

urlpatterns = [
    path("index/",      views.index,        name="main"),
    path("cocacola/",   views.cocacola,     name="product01"),
    path("pepsicola/",  views.pepsicola,    name="product02"),
    path("burrcola/",   views.burrcola,     name="product03"),
    path("sprite/",     views.sprite,       name="product04"),
    path("chilsung/",   views.chilsung,     name="product05"),
    path("burrcider/",  views.burrcider,    name="product06"),
    path("narangd/",    views.narangd,      name="product07"),
    path("nobrand/",    views.nobrand,      name="product08"),
    path("welchs/",     views.welchs,       name="product09"),
    path("oneam/",      views.oneam,        name="product10"),
    path("victoria/",   views.victoria,     name="product11"),
    path("minemine/",   views.minemine,     name="product12"),
    path("trevi/",      views.trevi,        name="product13"),
    path("reinwasser/", views.reinwasser,   name="product14"),
    path("seagram/",    views.seagram,      name="product15"),

]