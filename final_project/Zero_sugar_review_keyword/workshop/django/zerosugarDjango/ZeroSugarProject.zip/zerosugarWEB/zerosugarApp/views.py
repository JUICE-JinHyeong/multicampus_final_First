from django.shortcuts import render

# Create your views here.

from django.http import JsonResponse
from django.shortcuts import render, redirect

from .models import *

# Create your views here.

def index(request) :
    return render(request, 'zerosugar/index.html')

def cocacola(request) :
    return render(request, 'zerosugar/product01.html')

def pepsicola(request) :
    return render(request, 'zerosugar/product02.html')

def burrcola(request) :
    return render(request, 'zerosugar/product03.html')

def sprite(request) :
    return render(request, 'zerosugar/product04.html')

def chilsung(request) :
    return render(request, 'zerosugar/product05.html')

def burrcider(request) :
    return render(request, 'zerosugar/product06.html')

def narangd(request) :
    return render(request, 'zerosugar/product07.html')

def nobrand(request) :
    return render(request, 'zerosugar/product08.html')

def welchs(request) :
    return render(request, 'zerosugar/product09.html')

def oneam(request) :
    return render(request, 'zerosugar/product10.html')

def victoria(request) :
    return render(request, 'zerosugar/product11.html')

def minemine(request) :
    return render(request, 'zerosugar/product12.html')

def trevi(request) :
    return render(request, 'zerosugar/product13.html')

def reinwasser(request) :
    return render(request, 'zerosugar/product14.html')

def seagram(request) :
    return render(request, 'zerosugar/product15.html')


